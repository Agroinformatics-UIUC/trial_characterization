library(testthat)
library(soilDB)

test_check("soilDB")
