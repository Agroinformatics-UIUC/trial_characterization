if (requireNamespace("testthat")) {
  library(testthat)
  library(lmeInfo)

  test_check("lmeInfo")
}
